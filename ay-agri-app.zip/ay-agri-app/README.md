# A-Y-agri-for-plants

This app helps describe plant diseases and recommends treatments.
